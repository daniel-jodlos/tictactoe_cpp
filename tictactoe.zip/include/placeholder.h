//
// Created by danielj on 03.05.2020.
//

#ifndef TICTACTOE_PLACEHOLDER_H
#define TICTACTOE_PLACEHOLDER_H

template<class T> class Placeholder : public T {
public:
    Placeholder() = default;
};

#endif //TICTACTOE_PLACEHOLDER_H
